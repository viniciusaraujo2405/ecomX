import { Router } from 'express';
import { LojaController } from '../controllers/loja_controller';
import { authenticateJWT } from '../auth_middleware';

const router = Router();
const controller = new LojaController();

// Rotas protegidas (precisa estar autenticado para criar, atualizar, deletar)
router.post('/', authenticateJWT, controller.create);
router.put('/:id', authenticateJWT, controller.update);
router.delete('/:id', authenticateJWT, controller.delete);

// Rotas públicas 
router.get('/', controller.findAll);
router.get('/:id', async (req, res) => {
	try {
		await controller.findById(req, res);
	} catch (error) {
		res.status(500).send({ error: 'Internal Server Error' });
	}
});

export default router;
