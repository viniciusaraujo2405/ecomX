import { Request, Response } from 'express';
import { UsuarioRepository } from '../repositories/usuario_repository';

const usuarioRepo = new UsuarioRepository();

export class UsuarioController {
  async create(req: Request, res: Response) {
    try {
      const usuario = await usuarioRepo.create(req.body);
      res.status(201).json(usuario);
    } catch (error) {
      res.status(400).json({ error: 'Erro ao criar usuário', details: error });
    }
  }

  // Retorna apenas os dados do próprio usuário
  async getMyProfile(req: Request, res: Response): Promise<void> {
  try {
    const userId = (req as any).user.id;
    const usuario = await usuarioRepo.findById(userId);

    if (!usuario) {
      res.status(404).json({ error: 'Usuário não encontrado' });
      return;
    }

    res.json(usuario);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao buscar perfil', details: error });
  }
}


  async findAll(req: Request, res: Response) {
    try {
      const usuarios = await usuarioRepo.findAll();
      res.json(usuarios);
    } catch (error) {
      res.status(500).json({ error: 'Erro ao buscar usuários', details: error });
    }
  }

  async update(req: Request, res: Response) {
    try {
      const userId = (req as any).user.id;
      const usuario = await usuarioRepo.update(userId, req.body);
      res.json(usuario);
    } catch (error) {
      res.status(400).json({ error: 'Erro ao atualizar usuário', details: error });
    }
  }

  async delete(req: Request, res: Response) {
    try {
      const userId = (req as any).user.id;
      await usuarioRepo.delete(userId);
      res.status(204).send();
    } catch (error) {
      res.status(400).json({ error: 'Erro ao deletar usuário', details: error });
    }
  }
}
