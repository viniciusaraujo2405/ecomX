import express from 'express';
import dotenv from 'dotenv';
import usuarioRouter from './routes/usuario_route';
import lojaRouter from './routes/loja_route';
import authRouter from './routes/auth_route';
import { authenticateJWT } from './auth_middleware';
import { setupSwagger } from './schemas/swagger';

dotenv.config();

const app = express();
setupSwagger(app);
const port = process.env.PORT || 3000;

// Middleware para ler JSON no corpo da requisição
app.use(express.json());

// Rotas públicas (ex: autenticação)
app.use('/auth', authRouter);

// Rota raiz pública (sem autenticação)
app.get('/', (req, res) => {
  res.send('API EcomX rodando!');
});
app.use('/usuarios', usuarioRouter);
app.use('/lojas', lojaRouter);

app.listen(port, () => {
  console.log(`Servidor rodando na porta ${port}`);
});
