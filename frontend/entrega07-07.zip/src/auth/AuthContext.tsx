import { createContext, useContext, useState, useEffect } from 'react';
import type { ReactNode } from 'react';

// Define a interface para o tipo do contexto de autenticação [cite: 234]
interface AuthContextType {
  token: string | null; // O token de autenticação [cite: 236]
  setToken: (token: string | null) => void; // Função para definir o token [cite: 237]
  logout: () => void; // Função para fazer logout [cite: 238]
}

// Cria o contexto com um valor inicial undefined [cite: 239]
const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Provedor de autenticação que envolve a sua aplicação [cite: 239]
export function AuthProvider({ children }: { children: ReactNode }) {
  // Estado para armazenar o token, inicializando com o valor do localStorage (se existir) [cite: 240, 241]
  const [token, setToken] = useState<string | null>(() => {
    return localStorage.getItem('token');
  });

  // Efeito colateral para persistir o token no localStorage sempre que ele mudar [cite: 243]
  useEffect(() => {
    if (token) {
      localStorage.setItem('token', token); // Salva o token no localStorage [cite: 245]
    } else {
      localStorage.removeItem('token'); // Remove o token se for null [cite: 248]
    }
  }, [token]); // Dependência no token [cite: 249]

  // Função de logout que limpa o token e o localStorage [cite: 250]
  const logout = () => {
    setToken(null);
    localStorage.removeItem('token');
  };

  return (
    // Provedor que expõe o token, setToken e logout para os componentes filhos [cite: 256]
    <AuthContext.Provider value={{ token, setToken, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

// Hook personalizado para consumir o contexto de autenticação [cite: 260]
export function useAuth() {
  const context = useContext(AuthContext); // Acessa o contexto [cite: 261]
  if (!context) {
    // Lança um erro se useAuth for usado fora de AuthProvider [cite: 264]
    throw new Error('useAuth deve ser usado dentro de AuthProvider');
  }
  return context; // Retorna o contexto [cite: 266]
}