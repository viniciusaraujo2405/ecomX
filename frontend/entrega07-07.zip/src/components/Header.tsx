import { AppBar, Toolbar, Typography, IconButton, Button, Box } from '@mui/material';
import LightModeIcon from '@mui/icons-material/LightMode';
import DarkModeIcon from '@mui/icons-material/DarkMode';
import { useThemeMode } from '../theme/ThemeContext'; // Importe o hook do tema
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext'; // Importe o hook de autenticação [cite: 350]

const Header = () => {
  const { isDark, toggleTheme } = useThemeMode(); // Pega o estado do tema e a função para alternar [cite: 352]
  const { logout, token } = useAuth(); // Pega a função de logout e o token do contexto de autenticação [cite: 353]
  const navigate = useNavigate();

  const handleLogout = () => {
    logout(); // Chama a função de logout [cite: 357]
    navigate('/login'); // Redireciona para a página de login após o logout [cite: 358]
  };

  return (
    <AppBar position="static" color="primary" elevation={2}>
      <Toolbar sx={{ display: 'flex', justifyContent: 'space-between' }}>
        {/* Link para a página inicial (vitrine) */}
        <Typography variant="h6" component={Link} to="/" sx={{ textDecoration: 'none', color: 'inherit' }}>
          Meu E-commerce
        </Typography>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          {/* Botão para alternar tema */}
          <IconButton color="inherit" onClick={toggleTheme}>
            {isDark ? <LightModeIcon /> : <DarkModeIcon />}
          </IconButton>

          {/* Renderização condicional dos botões de Login/Sair */}
          {token ? ( // Se o usuário estiver logado [cite: 359]
            <Button color="inherit" onClick={handleLogout}>Sair</Button>
          ) : ( // Se o usuário não estiver logado
            <>
              <Button color="inherit" component={Link} to="/login">Login</Button>
              {/* Você pode adicionar um botão/link para a página de cadastro aqui também */}
              {/* <Button color="inherit" component={Link} to="/register">Cadastre-se</Button> */}
            </>
          )}
        </Box>
      </Toolbar>
    </AppBar>
  );
};

export default Header;