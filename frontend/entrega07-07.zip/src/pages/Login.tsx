import { useState } from 'react';
import {
  Box, Button, TextField, Typography, Snackbar, Alert,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import api from '../api/axios'; // Usamos a instância 'api' configurada com o interceptor

export default function Login() {
  const { setToken } = useAuth(); // Obtém a função setToken do contexto de autenticação [cite: 309]
  const navigate = useNavigate(); // Hook para navegação programática [cite: 310]

  const [email, setEmail] = useState(''); // Estado para o email (alterado de 'nome' para 'email') [cite: 311]
  const [senha, setSenha] = useState(''); // Estado para a senha [cite: 312]
  const [erro, setErro] = useState(''); // Estado para mensagens de erro [cite: 313]

  const handleLogin = async () => {
    setErro(''); // Limpa erros anteriores
    try {
      // Faz a requisição POST para a sua rota de login no backend [cite: 319]
      const response = await api.post('/auth/login', {
        email, // Envia o email (corrigido de nome) [cite: 322]
        senha, // Envia a senha [cite: 323]
      });

      const { token } = response.data; // Extrai o token da resposta [cite: 325]
      setToken(token); // Atualiza o contexto de autenticação e salva no localStorage [cite: 326]
      navigate('/'); // Redireciona para a página inicial (listagem de produtos) após o login [cite: 326]
    } catch (err: any) {
      console.error("Erro no login:", err.response || err); // Log para depuração
      setErro(err.response?.data?.error || 'Erro ao fazer login. Verifique suas credenciais.'); // Adapta para a mensagem de erro do seu backend [cite: 328]
    }
  };

  return (
    <Box
      display="flex"
      flexDirection="column"
      alignItems="center"
      justifyContent="center"
      height="100vh"
      px={2}
      gap={2}
    >
      <Typography variant="h4">Login</Typography>
      <TextField
        label="Email" // Label alterado para Email
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        fullWidth
      />
      <TextField
        label="Senha"
        type="password"
        value={senha}
        onChange={(e) => setSenha(e.target.value)}
        fullWidth
      />
      <Button variant="contained" fullWidth onClick={handleLogin}>
        Entrar
      </Button>
      <Snackbar open={!!erro} autoHideDuration={4000} onClose={() => setErro('')}>
        <Alert severity="error">{erro}</Alert>
      </Snackbar>
    </Box>
  );
}