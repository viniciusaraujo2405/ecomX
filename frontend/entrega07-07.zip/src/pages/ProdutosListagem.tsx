import React, { useEffect, useState } from 'react';
import api from '../api/axios'; // Usamos a instância 'api' configurada
import {
  Box, Typography, CircularProgress, Alert, Grid, Card, CardContent, CardHeader, Container,
} from '@mui/material';
import Header from '../components/Header'; // Importe o Header para incluir na página

// Interface que reflete a estrutura do seu objeto Produto vindo do backend
interface Produto {
  id: string;
  nome: string;
  descricao: string;
  estoque: number;
  preco: number;
  idVendedor: string;
  idCategoria: string;
  // Propriedades inclusas pelo findMany do ProdutoRepository
  vendedor: {
    nome: string;
  };
  categoria: {
    nome: string;
  };
}

export default function ProdutosListagem() {
  const [produtos, setProdutos] = useState<Produto[]>([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState('');

  useEffect(() => {
    const carregarProdutos = async () => {
      try {
        // Faz a requisição GET para a rota de listagem de produtos do seu backend
        const response = await api.get('/produtos'); // Verifique a rota exata no seu backend (ex: '/api/produtos')
        setProdutos(response.data);
      } catch (err: any) {
        console.error("Erro ao carregar produtos:", err.response || err);
        setErro('Erro ao carregar os produtos.');
      } finally {
        setCarregando(false);
      }
    };
    carregarProdutos();
  }, []); // O array vazio garante que o efeito só rode uma vez ao montar o componente

  return (
    <>
      <Header /> {/* Inclua o cabeçalho aqui para que ele apareça na página */}
      <Container maxWidth="lg" sx={{ py: 4 }}>
        <Typography variant="h4" gutterBottom textAlign="center">
          Catálogo de Produtos
        </Typography>
        {carregando ? (
          <Box display="flex" justifyContent="center" mt={4}>
            <CircularProgress />
          </Box>
        ) : erro ? (
          <Alert severity="error">{erro}</Alert>
        ) : (
          <Grid container spacing={3}>
            {produtos.map((produto) => (
              // Corrigido: Adicionado component="div" para resolver o erro de tipagem
              <Grid item xs={12} sm={6} md={4} key={produto.id} component="div">
                <Card elevation={3}>
                  <CardHeader title={produto.nome} />
                  <CardContent>
                    <Typography variant="body2" color="text.secondary">
                      **Preço:** R$ {produto.preco.toFixed(2)}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      **Estoque:** {produto.estoque} unidades
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      **Vendedor:** {produto.vendedor?.nome || 'N/A'} {/* Adicione verificação para 'vendedor' */}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      **Categoria:** {produto.categoria?.nome || 'N/A'} {/* Adicione verificação para 'categoria' */}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      **Descrição:** {produto.descricao}
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        )}
      </Container>
    </>
  );
}