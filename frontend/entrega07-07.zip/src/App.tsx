import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'; // Importa BrowserRouter, Routes e Route [cite: 422]
import { AuthProvider } from './auth/AuthContext'; // Importa o provedor de autenticação [cite: 423]
import { ThemeProvider } from './theme/ThemeContext'; // Importa o provedor de tema [cite: 424]
import PrivateRoute from './routes/PrivateRoute'; // Importa o componente de rota privada [cite: 425]

// Importa as páginas
import Login from './pages/Login'; // Página de Login [cite: 426]
import ProdutosListagem from './pages/ProdutosListagem'; // Sua página principal de listagem de produtos

// Exemplo de uma página que seria privada (você pode criar uma para o perfil do usuário ou painel do lojista)
// import Dashboard from './pages/Dashboard'; // Exemplo do professor para uma rota privada [cite: 427]

function App() {
  return (
    // Envolve a aplicação com os provedores de tema e autenticação [cite: 430, 432]
    <ThemeProvider>
      <AuthProvider>
        <Router> {/* O BrowserRouter gerencia o roteamento baseado na URL [cite: 433] */}
          <Routes> {/* Define as rotas da aplicação [cite: 433] */}
            {/* Rota para a página de login, acessível publicamente */}
            <Route path="/login" element={<Login />} />

            {/* Rota principal, que exibe a listagem de produtos. É pública. */}
            <Route path="/" element={<ProdutosListagem />} />

            {/* Exemplo de uma rota que exigiria autenticação (se você a implementar) */}
            {/* Por exemplo, um perfil do usuário ou um painel de lojista */}
            {/* <Route
              path="/dashboard"
              element={
                <PrivateRoute>
                  <Dashboard />
                </PrivateRoute>
              }
            /> */}
            {/* Você pode adicionar outras rotas aqui, protegidas ou não */}

            {/* Rota para páginas não encontradas (opcional, mas boa prática) */}
            {/* <Route path="*" element={<NotFound />} /> */}
          </Routes>
        </Router>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;